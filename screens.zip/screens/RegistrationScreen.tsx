import React, { useState, useRef, useEffect } from 'react';
import { View, TextInput, StyleSheet, Alert, TouchableOpacity, Text, Image, Animated, Easing } from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { auth, db } from '../firebase-config';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

type RegistrationScreenProps = {
  navigation: NativeStackNavigationProp<any, 'Sign up'>;
};

const RegistrationScreen: React.FC<RegistrationScreenProps> = ({ navigation }) => {
  const [name, setName] = useState(''); // Added state for name
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const backgroundColor = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const colors = ['#FAD02E', '#F76B1C', '#FF4E50'];

    const duration = 8000;

    const animateColors = () => {
      backgroundColor.setValue(0);
      Animated.timing(backgroundColor, {
        toValue: colors.length - 1,
        duration: duration,
        easing: Easing.linear,
        useNativeDriver: false,
      }).start(animateColors);
    };

    animateColors();
  }, []);

  const handleSignUp = async () => {
    try {
      // Create the user in Firebase Authentication
      const authUserCredential = await createUserWithEmailAndPassword(auth, email, password);
      const authUser = authUserCredential.user;
  
      // Create a user data object
      const userData = {
        name, // Assuming 'name' is the user's name
        email, // Assuming 'email' is the user's email
      };
  
    // Store user data in Firestore
    await setDoc(doc(db, 'users', authUser.uid), userData); // Use setDoc to add data

    Alert.alert('User created successfully');
  
      navigation.navigate('Sign in');
    } catch (error) {
      console.log('Error signing up:', error);
      Alert.alert('Failed to sign up');
    }
  };


  const colors = ['#FAD02E', '#F76B1C', '#FF4E50'];
  const interpolatedBackgroundColor = backgroundColor.interpolate({
    inputRange: colors.map((_, index) => index),
    outputRange: colors,
  });

  return (
    <Animated.View style={[styles.container, { backgroundColor: interpolatedBackgroundColor }]}>
      <View style={styles.contentContainer}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={styles.backButtonText}>⬅</Text>
        </TouchableOpacity>
        <Image source={require('./Images/2.png')} style={styles.logo} />
        <Text style={styles.title}>Sign up</Text>

        <TextInput
          style={styles.input}
          placeholder="Name"
          placeholderTextColor="white"
          value={name}
          onChangeText={setName}
        />

        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="white"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
        />

        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor="white"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TextInput
          style={styles.input}
          placeholder="Confirm Password"
          placeholderTextColor="white"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry
        />

        <TouchableOpacity style={styles.button} onPress={handleSignUp}>
          <Text style={styles.buttonText}>Register</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  contentContainer: {
    backgroundColor: 'rgba(0, 0,0 , 5)', // Updated background color for better contrast
    borderRadius: 30,
    padding: 20,
    width: '80%',
    alignItems: 'center',
    elevation: 50,
  },
  backButton: {
    position: 'absolute',
    top: 20,
    marginTop: -35,
    marginLeft: -5,
    left: 20,
  },
  backButtonText: {
    fontSize: 70,
    fontWeight: 'bold',
    color: 'yellow',
  },
  logo: {
    width: 200,
    height: 200,
    marginBottom: -15,
    borderRadius: 50,
    marginTop: -30,

  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
    color: 'yellow',
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 15,
    paddingHorizontal: 10,
    backgroundColor: 'black',
    borderRadius:30,
    color:'white'

  },
  button: {
    backgroundColor: 'yellow',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius:30,
    width: '48%',
    marginTop: 5,
    marginBottom: 12,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'black',
    textAlign:'center'
  },
});

export default RegistrationScreen;