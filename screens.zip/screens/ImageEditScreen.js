import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import ImageCropPicker from 'react-native-image-crop-picker';

const ImageEditScreen = ({ route }) => {
  const { image } = route.params;
  const [editedImage, setEditedImage] = useState(null);
 
  const openImagePicker = async () => {
    try {
      const croppedImage = await ImageCropPicker.openCropper({
        path: image,
        width: 300,
        height: 300,
        cropping: true,
        cropperCircleOverlay: true,
        compressImageQuality: 0.7,
      });

      setEditedImage(croppedImage.path);
    } catch (error) {
      console.log('Error cropping image:', error);
    }
  };

  
  return (
    <View style={styles.container}>
      <Text>Edit Image</Text>
      {editedImage && (
        <View>
          <Image source={{ uri: editedImage }} style={styles.editedImage} />
         
        </View>
      )}
      <TouchableOpacity style={styles.button} onPress={openImagePicker}>
        <Text style={styles.buttonText}>Open Image Picker</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  editedImage: {
    width: 200,
    height: 200,
    marginTop: 20,
  },
  button: {
    marginTop: 20,
    padding: 10,
    backgroundColor: 'blue',
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
  },
  filterButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  filterButton: {
    padding: 10,
    backgroundColor: 'blue',
    borderRadius: 5,
  },
});

export default ImageEditScreen;
