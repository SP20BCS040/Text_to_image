import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert, StyleSheet, TextInput } from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth, db } from '../firebase-config'
import { updatePassword, reauthenticateWithCredential, EmailAuthProvider} from 'firebase/auth';
import '@react-native-firebase/app';
import LinearGradient from 'react-native-linear-gradient';
import { doc, getDoc } from 'firebase/firestore';


type UserData = {
  name: string;
  email: string;
  // Add other properties if needed
};

type SettingsScreenProps = {
  navigation: NativeStackNavigationProp<any, any>;
  route: any; // Added route prop
};

const SettingsScreen: React.FC<SettingsScreenProps> = ({ navigation, route }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [userData, setUserData] = useState<UserData | null>(null);
  

  useEffect(() => {
    retrieveUserInfo();
    checkSession();
    
  }, []);

  const retrieveUserInfo = async () => {
    try {
      const user = auth.currentUser;

      if (user) {
        const uid = user.uid;
        const userDocRef = doc(db, 'users', uid);
        const userDocSnapshot = await getDoc(userDocRef);

        if (userDocSnapshot.exists()) {
          const userData = userDocSnapshot.data() as UserData; // Cast to UserData type
          setName(userData.name);
          setEmail(userData.email);
          setUserData(userData); // Update the userData state
          console.log('User Data:', userData); // Log the userData to the console

          await AsyncStorage.setItem('userData', JSON.stringify(userData));


        }
      }
    } catch (error) {
      console.log('Error retrieving user info:', error);
    }
  };

  const checkSession = async () => {
    try {
      // Check if user data is stored in AsyncStorage
      const userDataString = await AsyncStorage.getItem('userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        setName(userData.name);
        setEmail(userData.email);
        console.log('User Data from AsyncStorage:', userData); // Log the user data to the console
      }
    } catch (error) {
      console.log('Error checking session:', error);
    }
  };

//   const checkAuthentication = () => {
//     const user = auth.currentUser;

//     if (user) {
//         console.log('User is authenticated:', user.uid);
//     } else {
//         console.log('User is not authenticated');
//     }
// };

// // Call the function to check authentication status
// checkAuthentication();


const reauthenticate = async (setPassword: string) => {
  const user = auth.currentUser;

  if (user) {
    try {
      const email = user.email;

      if (email) {
        const cred = EmailAuthProvider.credential(email, setPassword);
        await reauthenticateWithCredential(user, cred);
        console.log("Reauthentication successful");
        return true; // Indicates successful reauthentication
      } else {
        console.log("User's email is null");
        return false; // Indicates reauthentication failure due to missing email
      }
    } catch (error) {
      console.error("Reauthentication failed:", error);
      return false; // Indicates reauthentication failure due to an error
    }
  } else {
    console.log("User is not authenticated");
    return false; // Indicates reauthentication failure due to user not being authenticated
  }
};
  

  const OnChangePassword = () => {

    reauthenticate(currentPassword).then(() => {

      const user = auth.currentUser;

      if (user) {
        updatePassword(user, newPassword)
          .then(() => {
            Alert.alert("Password was changed successfully. Please sign in again.");
            navigation.replace('Sign in');
          })
          .catch((error) => {
            Alert.alert(error.message);
          });
      } else {
        Alert.alert("User is not authenticated");
      }

    }).catch((error) => {
      Alert.alert(error.message);
    });

    setShowPasswordInput(false);
    setCurrentPassword("");  // Clear the input after saving
    setNewPassword(""); // Clear the input after saving

  };

  const handleSignOut = async () => {
    await AsyncStorage.removeItem('session')
      .then(() => {
        navigation.replace('Sign in');
        Alert.alert('Sign out Successfully');
      })
      .catch((error) => {
        console.log('Error removing session:', error);
        Alert.alert('Failed to sign out');
      });
  };

  return (
<LinearGradient colors={['black', 'purple']} style={styles.container}>

      <View>
        <Text style={styles.headerText}>My Account</Text>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.infoText}>Name</Text>
        <Text style={styles.infoValue}>{name}</Text>

        <Text style={styles.infoText}>Email</Text>
        <Text style={styles.infoValue}>{email}</Text>

        <TouchableOpacity onPress={() => setShowPasswordInput(!showPasswordInput)} style={styles.button}>
          <Text style={[styles.buttonText, { color: 'yellow' }]}>Change Password ▼</Text>
        </TouchableOpacity>

        {showPasswordInput && (
          <>
           <TextInput
              style={styles.input}
              placeholder="Type current password"
              secureTextEntry
              value={currentPassword}
              onChangeText={setCurrentPassword}
            />

            <TextInput
              style={styles.input}
              placeholder="Type new password"
              secureTextEntry
              value={newPassword}
              onChangeText={setNewPassword}
            />

            <TouchableOpacity onPress={OnChangePassword} style={[styles.saveButton, { backgroundColor: 'yellow' }]}>
              <Text style={[styles.buttonText, { color: 'black' }]}>Save</Text>
            </TouchableOpacity>
          </>
        )}

        <TouchableOpacity style={{marginTop:350,backgroundColor: 'red',borderRadius: 30,paddingVertical: 12,paddingHorizontal: 24,alignItems: 'center',}} onPress={handleSignOut}>
          <Text style={{ fontSize: 16, fontWeight: 'bold',textAlign: 'center',color:"black"}}>Log out</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111',
    padding: 20,
  },
  headerText: {
    fontSize: 30,
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
    marginTop: 5,
  },
  infoContainer: {
    borderTopWidth: 4,
    borderTopColor: 'yellow',
    marginTop: 9,
    borderTopLeftRadius: 50,
    borderTopRightRadius: 50,
    paddingTop: 20,
  },
  infoText: {
    color: 'white',
    marginTop: 15,
    fontSize: 22,
    fontWeight: 'bold',
  },
  infoValue: {
    color: 'black',
    backgroundColor: 'grey',
    borderRadius: 30,
    marginBottom: 10,
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  button: {
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    backgroundColor: 'grey',
    borderRadius: 30,
    marginBottom: 10,
    paddingHorizontal: 20,
    paddingVertical: 15,
    fontSize: 16,
  },
  saveButton: {
    backgroundColor: 'yellow',
    borderRadius: 30,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginBottom: 10,
    alignItems: 'center',
  },
});

export default SettingsScreen;