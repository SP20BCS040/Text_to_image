import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  StatusBar
} from 'react-native';
import {ProgressBar} from '@react-native-community/progress-bar-android';
import LinearGradient from 'react-native-linear-gradient';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Configuration, OpenAIApi } from 'openai';
import 'react-native-url-polyfill/auto';
import { db, storage } from '../firebase-config';
import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
} from 'firebase/storage';
import { addDoc, collection } from 'firebase/firestore';
import { useRoute } from '@react-navigation/native';

type HomeScreenProps = {
  navigation: NativeStackNavigationProp<any, 'Home'>;
};

interface HomeScreenRouteParams {
  recognizedText: string;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ navigation }) => {
  const route = useRoute();
  console.log('Route Params:', route.params);

  const recognizedText =
    (route.params as HomeScreenRouteParams)?.recognizedText || '';

  const [prompt, onChangePrompt] = useState('');
  const [result, setResult] = useState('');
  const [picture, setPicture] = useState('');
  const [loading, setLoading] = useState(false);
  const [imagePlaceholder, setImagePlaceholder] = useState(
    'https://furntech.org.za/wp-content/uploads/2017/05/placeholder-image-300x225.png'
  );
  const [refreshing, setRefreshing] = useState(false);

  const configuration = new Configuration({
    apiKey: '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',
  });

  const openai = new OpenAIApi(configuration);
  const preWrittenDescriptions = [
    "A cute cat",
    "A dog inside the water",
    "A horse inside a spaceship",
    "A monkey on Mars"
    // Add more descriptions as needed
  ];

  const handleRefresh = async () => {
    setRefreshing(true);

    // Reset state values to their initial state
    onChangePrompt('');
    setResult('');
    setPicture('');
    setLoading(false);
    setImagePlaceholder(
      'https://furntech.org.za/wp-content/uploads/2017/05/placeholder-image-300x225.png'
    );

    // Fetch any necessary data or perform other refresh logic here

    setRefreshing(false);
  };

  const clearText = () => {
    onChangePrompt('');
  };

  const insertRandomDescription = () => {
    const randomIndex = Math.floor(Math.random() * preWrittenDescriptions.length);
    const randomDescription = preWrittenDescriptions[randomIndex];
    onChangePrompt(randomDescription);
  };

  const generateImage = async () => {
    try {
      onChangePrompt(`${prompt}`);
      setLoading(true);
      const res = await openai.createImage({
        prompt: prompt,
        n: 1,
        size: "256x256",
      });
      setResult(res.data.data[0].url ?? 'default.jpg');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const [session, setSession] = useState<any>(null);
  useEffect(() => {
    onChangePrompt(recognizedText);
  }, [recognizedText]);

  useEffect(() => {
    retrieveSession();
  }, []);

  const retrieveSession = async () => {
    try {
      const sessionData = await AsyncStorage.getItem('session');
      if (sessionData !== null) {
        const sessionInfo = JSON.parse(sessionData);
        setSession(sessionInfo);
      }
    } catch (error) {
      console.log('Error retrieving session:', error);
    }
  };


  const navigateToCamera = () => {
    navigation.navigate('Camera');
  };

  useEffect(() => {
    const uploadImage = async () => {

      // convert image into blob image
      if (result) {
        const blobImage: Blob = await new Promise((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.onload = function () {
            resolve(xhr.response);
          };
          xhr.onerror = function () {
            reject(new TypeError("Newtwork request failed"));
          };
          xhr.responseType = "blob";
          xhr.open("GET", result, true);
          xhr.send(null);
        });

        // set metadata of image

        // Create the file metadata
        /** @type {any} */
        const metadata = {
          contentType: 'image/jpeg'
        };

        // upload image to storage

        // Upload file and metadata to the object 'images/mountains.jpg'
        const storageRef = ref(storage, 'generated/' + Date.now());
        const uploadTask = uploadBytesResumable(storageRef, blobImage, metadata);

        // Listen for state changes, errors, and completion of the upload.
        uploadTask.on('state_changed',
          (snapshot) => {
            // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            console.log('Upload is ' + progress + '% done');
            switch (snapshot.state) {
              case 'paused':
                console.log('Upload is paused');
                break;
              case 'running':
                console.log('Upload is running');
                break;
            }
          },
          (error) => {
            // A full list of error codes is available at
            // https://firebase.google.com/docs/storage/web/handle-errors
            switch (error.code) {
              case 'storage/unauthorized':
                // User doesn't have permission to access the object
                break;
              case 'storage/canceled':
                // User canceled the upload
                break;

              // ...

              case 'storage/unknown':
                // Unknown error occurred, inspect error.serverResponse
                break;
            }
          },
          () => {
            // Upload completed successfully, now we can get the download URL
            getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
              console.log('File available at', downloadURL);
              setPicture(downloadURL);
            });
          }
        );

      }
    }

    if (result != null) {
      uploadImage();
      // setResult("");
    }

  }, [result]);


  const uploadGenerated = async () => {

    if (picture && prompt) {
      const docRef = await addDoc(collection(db, "generated"), {
        Title: prompt,
        Picture: picture
      })

        .then(() => {
          console.log("Generated uploaded successfully");
        })

        setPicture("");
    }
  }

  useEffect(() => {
    uploadGenerated ();
  }, [picture]);



  return (
    <LinearGradient colors={['black', 'purple']} style={styles.container}>
      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={['#0000ff']} />
        }
      >


      <View style={styles.header}>
        <Image source={require('./Images/2.png')} style={styles.logo} />
        <Text style={styles.heading}>Word Vision</Text>
      </View>

      <Text style={styles.subtitle}>Bring Your Words to Life!</Text>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter your text..."
          onChangeText={(text) => onChangePrompt(text)}
          value={prompt}
          multiline
          numberOfLines={4}
          placeholderTextColor="#777"
        />
        <TouchableOpacity style={styles.cameraButton} onPress={navigateToCamera}>
          <Icon name="photo-camera" size={30} color="white" />
        </TouchableOpacity>
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={insertRandomDescription}>
          <Text style={styles.buttonText}>Try an Example</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={clearText}>
          <Text style={[styles.buttonText, styles.clearButton]}>Clear</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.generateButton} onPress={generateImage}>
        <Text style={styles.generateButtonText}>Generate</Text>
      </TouchableOpacity>

      {loading && (
        <View style={styles.loadingContainer}>
            <View style={{ width: 300  }}>
              <ProgressBar styleAttr="Horizontal" color="white" progress={0.5} />
            </View>
          <Text style={styles.loadingText}>Generating...</Text>
        </View>
      )}

      <View style={styles.imageContainer}>
        <Image
          style={styles.generatedImage}
          source={{ uri: result || imagePlaceholder }}
        />
      </View>

      <StatusBar barStyle="light-content" backgroundColor="black" />

              {/* {session && (
          <View style={styles.sessionContainer}>
            <Text style={styles.sessionText}>User ID: {session.userId}</Text>
            <Text style={styles.sessionText}>Email: {session.email}</Text>
          </View>
        )} */}
    

    </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  buttonContainer: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  
  buttonText: {
    color: 'white',
    fontSize: 15,
  },

  clearButton: {
    marginLeft: 190, // Adjust this value as needed to move the Clear button left
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 4,
    borderBottomColor: 'white',
    marginBottom: 20,
    paddingBottom: 10,
    borderBottomLeftRadius: 50,
    borderBottomRightRadius: 50,
  },
  logo: {
    width: 100,
    height: 70,
    borderRadius: 40,
    marginLeft: -80,
  },
  heading: {
    color: 'white',
    fontSize: 30,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  subtitle: {
    color: '#bbb',
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 25,
    paddingHorizontal: 15,
    marginBottom: 15,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color:'black'
  },
  cameraButton: {
    backgroundColor: 'blue',
    borderRadius: 25,
    padding: 10,
    marginLeft: 10,
  },
  generateButton: {
    backgroundColor: 'yellow',
    borderRadius: 30,
    padding: 15,
    alignItems: 'center',
    marginBottom: 20,
    marginHorizontal:70
  },
  generateButtonText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  loadingText: {
    marginTop: 10,
    color: 'white',
  },
  imageContainer: {
    alignItems: 'center',
  
  },
  generatedImage: {
    width: 300,
    height: 300,
    resizeMode: 'contain',
    borderRadius:30,
    marginTop:10,
  },
  sessionContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
    margin: 10,
  },
  sessionText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 5,
  },
});

export default HomeScreen;